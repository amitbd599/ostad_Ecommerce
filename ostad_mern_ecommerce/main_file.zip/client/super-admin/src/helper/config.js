export const hostURL = "http://localhost:5000";
export const baseURL = "/api/v1";
export const baseURLFile = "/api/v1/get-file";

/*


src={`${baseURLFile}/${item?.category_img}`}

http://localhost:5173/all-products?category_id=10&brand_id=5&remark=sale&keyword=bag&per_page=20&page_no=2



*/
